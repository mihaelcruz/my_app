<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Diseño responsivo</title>
    <link rel="stylesheet" href="css/estilos.css" type="text/css">
  </head>

  <body>
<h1>Diseño responsivo</h1>
<div class="imagen">

</div>
  </body>
</html>
